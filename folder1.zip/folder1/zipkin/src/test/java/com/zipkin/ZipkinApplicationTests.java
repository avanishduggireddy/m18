package com.zipkin;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ZipkinApplicationTests {

	@Test
	public void contextLoads() {
	}
	
	public ZipkinApplicationTests() {
	
	}
	
	

	
}
